﻿#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QMainWindow>
#include <QToolBar>
#include "SplineSeriesWidget.h"
#include "DataManger.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QMainWindow *parent = nullptr);
    ~MainWindow();

    void initTool();
private slots:
    void storeFile(bool flag);
    void replayFile(bool flag);
private:
    SplineSeriesWidget *m_ss_widget;
    QToolBar *tool;

    QAction *action_save;
    QAction *action_replay;

    DataManger *dm;
};

#endif // MAINWIDGET_H
