﻿#include "SplineSeriesWidget.h"
#include <QVBoxLayout>
#include <QMessageBox>
#include <QColor>
#include <QDebug>

/**
 * @brief SplineSeriesWidget::SplineSeriesWidget
 * @param parent
 * 曲线绘制页面
 */
SplineSeriesWidget::SplineSeriesWidget(QWidget *parent) : QWidget(parent)
{
    this->setupChartView();//初始化绘制界面
    //布局
    QVBoxLayout *v_layout = new QVBoxLayout();
    v_layout->setContentsMargins(3,6,3,6);
    v_layout->addWidget(m_ad1_chartView);
    v_layout->addWidget(m_ad2_chartView);
    this->setLayout(v_layout);

}

SplineSeriesWidget::~SplineSeriesWidget()
{

}

void SplineSeriesWidget::updatePlot(QVector<QPointF> &ad1, QVector<QPointF> &ad2, QVector<QPointF> &ad3, QVector<QPointF> &ad4)
{
    m_ad1_series->replace(ad1);
    m_ad1_series->replace(ad2);
    m_ad1_series->replace(ad3);
    m_ad1_series->replace(ad4);

}




void SplineSeriesWidget::setupChartView()
{
    m_ad1_series = new QSplineSeries();
    m_ad2_series = new QSplineSeries();
    m_ad3_series = new QSplineSeries();
    m_ad4_series = new QSplineSeries();
    m_ad5_series = new QSplineSeries();
    m_ad6_series = new QSplineSeries();
    m_ad7_series = new QSplineSeries();
    m_ad8_series = new QSplineSeries();

    m_ad1_series->setName("AD1");
    m_ad2_series->setName("AD2");
    m_ad3_series->setName("AD3");
    m_ad4_series->setName("AD4");
    m_ad5_series->setName("AD5");
    m_ad6_series->setName("AD6");
    m_ad7_series->setName("AD7");
    m_ad8_series->setName("AD8");

    m_ad1_series->setColor(QColor("#00BFFF"));
    m_ad2_series->setColor(QColor("#6495ED"));
    m_ad3_series->setColor(QColor("#1E90FF"));
    m_ad4_series->setColor(QColor("#4169E1"));

    m_ad5_series->setColor(QColor("#00BFFF"));
    m_ad6_series->setColor(QColor("#6495ED"));
    m_ad7_series->setColor(QColor("#1E90FF"));
    m_ad8_series->setColor(QColor("#4169E1"));


    //    m_x_axis = new QValueAxis();
    //    m_y_axis = new QValueAxis();




    m_ad1_series->setUseOpenGL(true);//开启绘图加速
    m_ad1_series->setColor(Qt::blue);
    m_ad1_series->setVisible(true);

    m_ad1_chart = new QChart();
    m_ad1_chart->setTheme(QChart::ChartThemeLight);
    m_ad1_chart->setDropShadowEnabled(true);
    m_ad1_chart->addSeries(m_ad1_series);
    m_ad1_chart->addSeries(m_ad2_series);
    m_ad1_chart->addSeries(m_ad3_series);
    m_ad1_chart->addSeries(m_ad4_series);
    //    m_ad1_chart->legend()->hide();//隐藏图例

    m_ad1_chart->layout()->setContentsMargins(3,6,3,6);
    m_ad1_chart->createDefaultAxes();//创建默认坐标系
    //    m_ad1_chart->axisX()->setRange(1,501);
    //    m_ad1_chart->axisY()->setRange(1,501);//配置坐标系显示范围
    m_ad1_chart->setTitle("通道1");
    m_ad1_chartView = new ChartView(m_ad1_chart);
    m_ad1_chartView->setRenderHint(QPainter::Antialiasing);//渲染方式
    m_ad1_chartView->setRubberBand(QChartView::RectangleRubberBand);

    m_ad2_chart = new QChart();

    m_ad2_series->setUseOpenGL(true);

    m_ad2_series->setColor(Qt::blue);

    m_ad2_series->setVisible(true);

    m_ad2_chart->setTheme(QChart::ChartThemeLight);
    m_ad2_chart->setDropShadowEnabled(true);
    m_ad2_chart->addSeries(m_ad5_series);
    m_ad2_chart->addSeries(m_ad6_series);
    m_ad2_chart->addSeries(m_ad7_series);
    m_ad2_chart->addSeries(m_ad8_series);
    m_ad2_chart->createDefaultAxes();
    //    m_ad2_chart->legend()->hide();// 隐藏图例

    m_ad2_chart->setTitle("通道2");
    m_ad2_chart->layout()->setContentsMargins(3,6,3,6);
    m_ad2_chartView = new ChartView(m_ad2_chart);
    m_ad2_chartView->setRenderHint(QPainter::Antialiasing);



}
