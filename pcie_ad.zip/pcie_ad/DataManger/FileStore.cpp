﻿#include "FileStore.h"
#include <QFileDialog>
#include <QDebug>

/**
 * @brief FileStore::FileStore
 * @param _name
 * @param parent
 * 数据存储类
 */
FileStore::FileStore(QString _name,QObject *parent) : QObject(parent),name(_name)
{
    file = new QFile(name);
    if(!file->open(QIODevice::WriteOnly | QIODevice::Append))
    {
        qDebug() << "ERROR:File Open Failed";
    }
    else
    {
        qDebug() << "INFO:Create "<<name << "File";
    }

}

FileStore::~FileStore()
{
    file->close();
    delete file;
    file = nullptr;

    qDebug() << "INFO:Close" << name <<"File";
}

void FileStore::fileStore(const QByteArray &data)
{
    file->write(data);
}

