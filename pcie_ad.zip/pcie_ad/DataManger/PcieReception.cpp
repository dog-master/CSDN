﻿#include "PcieReception.h"
#include "PcieFun.h"
#include "DataManger.h"
#include <QMessageBox>
#include <QDebug>
#include <QByteArray>
#define FPGA_DDR_START_ADDR 0 //文件读取起始位置

static DAQ7606 *buf = nullptr;
static int cnt = 0;


// tmp
static long cnt0 =0;
static long cnt1 =0;

PcieReception::PcieReception(QObject *parent) : QObject (parent)
{
    if(pcie_init() <= 0) //pcie 初始化
    {
        qDebug()<<"ERROR:PCIe init error";
    }
    else
    {
        qDebug()<<"PCIe init success";
    }
}

PcieReception::~PcieReception()
{
    pcie_deinit(); //pcie 关闭操作
}


void PcieReception::setFileStorePtr(FileStore *_fs)
{
    m_fs = _fs;
}

void PcieReception::nullFillStorePtr()
{
    m_fs = nullptr;
}


void PcieReception::updateData(bool b_fs,QVector<QPointF>&ad1,
                                   QVector<QPointF>&ad2,
                                   QVector<QPointF>&ad3,
                                   QVector<QPointF>&ad4)
{
    double val1,val2,val3,val4;

    if(cnt==0)
    {
        get_data_from_fpga_ddr(FPGA_DDR_START_ADDR,c2h_align_mem_tmp,FPGA_DDR_READ_SIZE); //读取16384字节  4通道 16b 2048点数据 可以自行计算
        DAQ7606 *ptmp =(DAQ7606 *)c2h_align_mem_tmp;

        if(b_fs && m_fs)//标志位加指针非空双重判断 若满足写文件
        {
            m_fs->fileStore(QByteArray((char*)c2h_align_mem_tmp,FPGA_DDR_READ_SIZE));
        }
        buf = ptmp;
        ad1.erase(ad1.begin(),ad1.begin()+2048); //数据动画内存分配操作 将旧数据剔除之后增加新数据
        ad2.erase(ad2.begin(),ad2.begin()+2048); //数据动画内存分配操作 将旧数据剔除之后增加新数据
        ad3.erase(ad3.begin(),ad3.begin()+2048); //数据动画内存分配操作 将旧数据剔除之后增加新数据
        ad4.erase(ad4.begin(),ad4.begin()+2048); //数据动画内存分配操作 将旧数据剔除之后增加新数据
    }

    while(cnt<=2048)
    {
        val1=buf->ad0*ad_cave;
        val2=buf->ad1*ad_cave;
        val3=buf->ad2*ad_cave;
        val4=buf->ad3*ad_cave;

        ad1.append({0,val1});
        ad2.append({0,val2});
        ad3.append({0,val2});
        ad4.append({0,val2});

        buf++;
        cnt++;
    }
    cnt=0;


    for(int i=X_BEGIN;i<X_END;i++) //绘图坐标重新配置
    {
        ad1[i-1].setX(double(i)/1000-5);//修正x坐标
        ad2[i-1].setX(double(i)/1000-5);//修正x坐标
        ad3[i-1].setX(double(i)/1000-5);//修正x坐标
        ad4[i-1].setX(double(i)/1000-5);//修正x坐标
    }

}
