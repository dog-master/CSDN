﻿#ifndef FILEREPLAY_H
#define FILEREPLAY_H

#include <QObject>
#include <QString>
#include <QFile>
#include <QTimer>
#include <QPointF>
#include "PcieFun.h"
class FileReplay : public QObject
{
    Q_OBJECT
    friend class DataManger;
public:
    explicit FileReplay(QString _name,QObject *parent = nullptr);
    ~FileReplay();
signals:

public slots:

private:
    void fileRead(QVector<QPointF>&,
                  QVector<QPointF>&,
                  QVector<QPointF>&,
                  QVector<QPointF>&);
    QString name;
    QFile *file;
    QTimer *timer;

    char* buffer;
    int cnt;
    DAQ7606 *daq;
};

#endif // FILEREPLAY_H
