﻿#ifndef FILESTORE_H
#define FILESTORE_H

#include <QObject>
#include <QString>
#include <QFile>
#include <QByteArray>
#include "PcieReception.h"
class FileStore : public QObject
{
    Q_OBJECT
    friend class PcieReception;
public:
    explicit FileStore(QString _name,QObject *parent = nullptr);
    ~FileStore();
private:
    void fileStore(const QByteArray &data);

    QFile *file;
    QString name;

};

#endif // FILESTORE_H
