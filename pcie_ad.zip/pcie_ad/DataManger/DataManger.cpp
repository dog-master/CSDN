﻿#include "DataManger.h"
#include <QDebug>
#include <unistd.h>

/**
 * @brief DataManger::DataManger
 * @param parent
 * 数据管理的总类 对回放 pcie收数 存数做管理调度
 * 回放 存数分别用两个类做动态处理
 * 相关状态用标志位来描述
 */
DataManger::DataManger(QObject *parent) : QObject(parent)
{
    pcie_flag = true;
    replay_flag = false;//
    store_flag = false;

    b_thread_exit_flag = false;
    pr =new PcieReception();

    t_read_data = new std::thread(&DataManger::updateData,this);

    //    updateTimer->setInterval(1000);
    //内存开辟
    m_ad1_data.resize(X_END-X_BEGIN);
    m_ad2_data.resize(X_END-X_BEGIN);
    m_ad3_data.resize(X_END-X_BEGIN);
    m_ad4_data.resize(X_END-X_BEGIN);
    m_ad5_data.resize(X_END-X_BEGIN);
    m_ad6_data.resize(X_END-X_BEGIN);
    m_ad7_data.resize(X_END-X_BEGIN);
    m_ad8_data.resize(X_END-X_BEGIN);


}


/**
 * @brief DataManger::~DataManger
 * @todo 后续增加相关析构
 */
DataManger::~DataManger()
{
    b_thread_exit_flag = true;

    if(t_read_data->joinable()){
        t_read_data->join();
        qDebug() << "read data thread exit";
    }

    delete  t_read_data;
    delete  fs;
    delete  fr;
    delete  pr;

    fs = nullptr;
    fr = nullptr;
    pr = nullptr;
    t_read_data = nullptr;
}

void DataManger::updateData()
{
    if(pcie_flag && !replay_flag)
    {
        while(!b_thread_exit_flag)
        {
            pr->updateData(store_flag,m_ad1_data,m_ad2_data,m_ad3_data,m_ad4_data);
            usleep(40000);
            qDebug() << "thread exe";
        }

        emit updateSignal(m_ad1_data,m_ad2_data,m_ad3_data,m_ad4_data);//发送数据信号 此处为引用传递 避免值拷贝
    }

    if(replay_flag)
    {
        if(fr)
        {
            fr->fileRead(m_ad1_data,m_ad1_data,m_ad1_data,m_ad1_data);
            emit updateSignal(m_ad1_data,m_ad1_data,m_ad1_data,m_ad1_data);
        }
    }
}


void DataManger::openFileStore(QString name)
{
    if(!fs && store_flag) //文件存储指针不为空 且标志位满足   创建该类对象 传递该指针至Pcie类
    {
        fs = new FileStore(name);
        pr->setFileStorePtr(fs);//设置存储文件指针
    }
    else
    {
        qDebug()<<"INFO:<<File Created";
    }
}

void DataManger::openFileReplay(QString name)
{
    if(!fr && replay_flag)
    {
        fr = new FileReplay(name);
    }
    else
    {
        qDebug()<<"INFO:<<File Created";
    }
}

void DataManger::closeFileStore()
{
    if(fs && !store_flag)
    {
        pr->nullFillStorePtr();//文件指针置空
        delete  fs;
        fs = nullptr;
    }
    else
    {
        qDebug() << "ERROR:Closed Failed";
    }
}

void DataManger::closeFileReplay()
{
    if(fr && !replay_flag)
    {
        delete  fr;
        fr = nullptr;
    }
    else
    {
        qDebug() << "ERROR:Closed Failed";
    }
}


