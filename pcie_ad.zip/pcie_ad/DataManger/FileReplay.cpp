﻿#include "FileReplay.h"
#include "DataManger.h"
#include <QDebug>

/**
 * @brief FileReplay::FileReplay
 * @param _name
 * @param parent
 * 数据回放类
 */
FileReplay::FileReplay(QString _name,QObject *parent) : QObject(parent),name(_name)
{
    file = new QFile();
    timer = new QTimer();
    if(!file->open(QIODevice::ReadOnly | QIODevice::Append))
    {
        buffer = (char*)malloc(FPGA_DDR_READ_SIZE*sizeof (char));
        cnt = 0;
        daq = nullptr;
        qDebug() <<"ERROR:Replay File Open Failed";
    }
    else
    {
        qDebug() << "INFO:Replay Open" << name <<"File";
    }
}


FileReplay::~FileReplay()
{
    file->close();
    this->killTimer(timer->timerId());
    delete  file;
    delete buffer;
    delete  timer;

    buffer = nullptr;
    file = nullptr;
    timer = nullptr;
    qDebug() << "INFO:Close" << name <<"Replay File";
}


/**
 * @brief FileReplay::fileRead
 * @param ad1
 * @param ad2
 * @param ad3
 * @param ad4
 * 与pcie逻辑类似
 */
void FileReplay::fileRead(QVector<QPointF>&ad1,
                          QVector<QPointF>&ad2,
                          QVector<QPointF>&ad3,
                          QVector<QPointF>&ad4)
{
    double val1,val2,val3,val4;


    if(cnt == 0)
    {
        file->read(buffer,FPGA_DDR_READ_SIZE);
        DAQ7606 *ptmp = (DAQ7606 *)buffer;

        daq = ptmp;
        ad1.erase(ad1.begin(),ad1.begin()+2048);
    }

    while(cnt<=2048)
    {
        val1=daq->ad0*ad_cave;
        val2=daq->ad1*ad_cave;
        val3=daq->ad2*ad_cave;
        val4=daq->ad3*ad_cave;

        ad1.append({0,val1});
        ad2.append({0,val2});
        ad3.append({0,val2});
        ad4.append({0,val2});

        daq++;
        cnt++;
    }
    cnt=0;

    for(int i=X_BEGIN;i<X_END;i++)
    {
        ad1[i-1].setX(double(i)/1000-5);//修正x坐标
        ad2[i-1].setX(double(i)/1000-5);//修正x坐标
        ad3[i-1].setX(double(i)/1000-5);//修正x坐标
        ad4[i-1].setX(double(i)/1000-5);//修正x坐标
    }
}






