﻿#ifndef PCIERECEPTION_H
#define PCIERECEPTION_H

#include <QObject>
#include <QTimer>
#include <QVector>
#include "PcieFun.h"
class FileStore;

class PcieReception :public QObject
{
    Q_OBJECT
    friend class DataManger;
public:
    explicit PcieReception(QObject *parent = nullptr);
    ~PcieReception();


    void setFileStorePtr(FileStore *_fs); //这里传入回放文件类的指针用来做处理
    void nullFillStorePtr();
private:
    void updateData(bool b_fs,QVector<QPointF>&ad1,
                        QVector<QPointF>&ad2,
                        QVector<QPointF>&ad3,
                        QVector<QPointF>&ad4);//增加存储标志位判断
    FileStore *m_fs; //不需要空间释放


};

#endif // PCIERECEPTION_H
