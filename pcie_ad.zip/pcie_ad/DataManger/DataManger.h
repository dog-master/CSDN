﻿#ifndef DATAMANGER_H
#define DATAMANGER_H

#include <QObject>
#include <QVector>
#include <thread>
#include "FileStore.h"
#include "FileReplay.h"
#include "PcieReception.h"

#define X_BEGIN 1
#define X_END 5001
#define FPGA_DDR_READ_SIZE 16384
const static qreal ad_cave = ((qreal)20.0)/65536;
class DataManger : public QObject
{
    Q_OBJECT
public:
    explicit DataManger(QObject *parent = nullptr);
    ~DataManger();

    void openFileStore(QString name);
    void openFileReplay(QString name);
    void closeFileStore();
    void closeFileReplay();

    inline void setStoreFlag(bool flag){store_flag = flag;}
    inline void setPcieFlag(bool flag){pcie_flag = flag;}
    inline void setReplayFlag(bool flag){replay_flag = flag;}
signals:
    void updateSignal(QVector<QPointF>&,
                      QVector<QPointF>&,
                      QVector<QPointF>&,
                      QVector<QPointF>&);//四路数据

public slots:
    void updateData();
private:



    bool replay_flag;
    bool pcie_flag;
    bool store_flag;

    bool b_thread_exit_flag;
    FileStore *fs = nullptr;
    FileReplay *fr = nullptr;
    PcieReception *pr = nullptr;

    std::thread *t_read_data;

    QVector<QPointF> m_ad1_data;                         //曲线数据
    QVector<QPointF> m_ad2_data;
    QVector<QPointF> m_ad3_data;
    QVector<QPointF> m_ad4_data;
    QVector<QPointF> m_ad5_data;
    QVector<QPointF> m_ad6_data;
    QVector<QPointF> m_ad7_data;
    QVector<QPointF> m_ad8_data;
};

#endif // DATAMANGER_H
