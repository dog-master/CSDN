﻿#ifndef PCIE_FUNC_H
#define PCIE_FUNC_H
#ifdef __cplusplus
#include <stdint.h>
 extern "C" {
 #endif
int pcie_init();
void pcie_deinit();
void put_data_to_fpga_ddr(long fpga_ddr_addr,unsigned char *buffer,unsigned int len);
void get_data_from_fpga_ddr(long fpga_ddr_addr,unsigned char *buffer,unsigned int len);
void write_control(long addr,uint32_t val);
void read_control(long addr,uint32_t *val);

struct DAQ7606
{
  short ad0;
  short ad1;
  short ad2;
  short ad3;
};

extern unsigned char *h2c_align_mem_tmp;
extern unsigned char *c2h_align_mem_tmp;

#ifdef __cplusplus
}
#endif
#endif
