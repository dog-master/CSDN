﻿#ifndef SPLINESERIESWIDGET_H
#define SPLINESERIESWIDGET_H

#include <QWidget>
#include <QtCharts>
#include <QTimer>
#include "ChartView.h"

class SplineSeriesWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SplineSeriesWidget(QWidget *parent = nullptr);
    virtual ~SplineSeriesWidget();
public slots:
    void updatePlot(QVector<QPointF>&,
    QVector<QPointF>&,
    QVector<QPointF>&,
    QVector<QPointF>&);

private:
    void setupChartView();

    QSplineSeries *m_ad1_series;                          //曲线数据序列
    QSplineSeries *m_ad2_series;                          //曲线数据序列
    QSplineSeries *m_ad3_series;                          //曲线数据序列
    QSplineSeries *m_ad4_series;                          //曲线数据序列
    QSplineSeries *m_ad5_series;                          //曲线数据序列
    QSplineSeries *m_ad6_series;                          //曲线数据序列
    QSplineSeries *m_ad7_series;                          //曲线数据序列
    QSplineSeries *m_ad8_series;                          //曲线数据序列

    QChart *m_ad1_chart;                                //图表
    QChart *m_ad2_chart;                                //图表

//    QValueAxis *m_x_axis;
//    QValueAxis *m_y_axis;

    ChartView* m_ad1_chartView;
    ChartView* m_ad2_chartView;
};

#endif // SPLINESERIESWIDGET_H
