﻿#include "MainWindow.h"
#include <QVBoxLayout>
#include <QIcon>
#include <QFileDialog>
MainWindow::MainWindow(QMainWindow *parent) :
    QMainWindow(parent)

{
    initTool();//工具栏初始化
    m_ss_widget = new SplineSeriesWidget();//曲线显示页面
    dm = new DataManger();//数据管理类

    this->setCentralWidget(m_ss_widget);
    this->resize(800,500);

    connect(action_save,SIGNAL(triggered(bool)),this,SLOT(storeFile(bool)));//两个action的槽函数
    connect(action_replay,SIGNAL(triggered(bool)),this,SLOT(replayFile(bool)));
    connect(dm,SIGNAL(updateSignal(QVector<QPointF>&,
                            QVector<QPointF>&,
                            QVector<QPointF>&,
                            QVector<QPointF>&)),m_ss_widget,SLOT(updatePlot(QVector<QPointF>&,
                                                                 QVector<QPointF>&,
                                                                 QVector<QPointF>&,
                                                                 QVector<QPointF>&)));
}

MainWindow::~MainWindow()
{

}

void MainWindow::initTool()
{
    tool = new QToolBar();
    this->addToolBar(tool);

    action_save = new QAction(QIcon(":/res/save.svg"),"");
    action_replay = new QAction(QIcon(":/res/file.svg"),"");//图标设置


    action_save->setToolTip("保存文件");
    action_replay->setToolTip("回放文件");

    action_save->setCheckable(true);
    action_replay->setCheckable(true);

    tool->addAction(action_replay);
    tool->addAction(action_save);
}

void MainWindow::storeFile(bool flag)
{
    if(flag)
    {
        auto time = "AD_"+QDate::currentDate().toString("yyyyMMdd");
        time+=QTime::currentTime().toString("hhmm");//获取时间字符串用来生成文件名 用做下面函数的第三个参数 作为默认文件名
        auto file_name = QFileDialog::getSaveFileName(this,tr("Open File"),"./"+time,"*.dat");//获取保存文件名
        if(!file_name.isEmpty())
        {
            dm->setStoreFlag(true);
            dm->openFileStore(file_name);
        }
        else
        {
            qDebug()<< "INFO:Store Filename Empty";
        }

    }
    else
    {
        dm->setStoreFlag(false);
        dm->closeFileStore();
    }
}

void MainWindow::replayFile(bool flag)
{
    if(flag)
    {
        auto file_name = QFileDialog::getOpenFileName();
        if(file_name.isEmpty())
        {
            dm->setReplayFlag(true);
            dm->openFileReplay(file_name);
        }
        else
        {
            qDebug()<< "INFO:Replay Filename Empty";
        }
    }
    else
    {
        dm->setReplayFlag(false);
        dm->closeFileReplay();
    }
}


