﻿#include "widget.h"

#include <QHostAddress>
#include <QDebug>
#include <QLineEdit>
#include <QListView>
#include <QStandardItemModel>
#include <QMouseEvent>

Widget::Widget(QWidget *parent)
    : QWidget(parent),
      ui(new Ui::Form)
{
    ui->setupUi(this);

//    ip = "192.128.1.200";
    ip = "127.0.0.1";
    port = "20000";

    //ui config
    ui->lineEdit_ip->setText(ip);
    ui->lineEdit_port->setText(port);

    server = new QTcpServer();

    connect(ui->pushButtonConnected,SIGNAL(clicked()),this,SLOT(newListen()));
    connect(ui->pushButton_send,SIGNAL(clicked()),this,SLOT(sendData()));
}

Widget::~Widget()
{

}

void Widget::newListen()
{
    ip = ui->lineEdit_ip->text();
    port = ui->lineEdit_port->text();

    // There is no security check for ip and port, only check if it is empty
    if(!ip.isEmpty() && !port.isEmpty())
    {
        qDebug() << "server listen" << ip << " " << port;
        server->close();
        server->listen(QHostAddress(ip),port.toUShort());
        connect(server,SIGNAL(newConnection()),this,SLOT(newConnetion()));
    }
    else
    {
        qDebug() << "listen parameter error";
        return;
    }
}

void Widget::newConnetion()
{
    QTcpSocket *tmp = server->nextPendingConnection();

    QString str = tmp->peerAddress().toString() + ":" + QString::number(tmp->peerPort());
    s_map.insert(str,tmp);

    ui->comboBox_client->addItem(str);
    connect(tmp,SIGNAL(readyRead()),this,SLOT(getData()));
}

void Widget::getData()
{
    QString out =  ((QTcpSocket*)sender())->peerAddress().toString() +":"+ QString::number(((QTcpSocket*)sender())->peerPort())+"\n";
    out += ((QTcpSocket*)sender())->readLine();

    ui->textBrowser->append(out);
}

void Widget::sendData()
{


    QTcpSocket* socket = s_map[ui->comboBox_client->currentText()];

    QString str =  ui->plainTextEdit->toPlainText();
    qDebug() <<str;
    socket->write(str.toStdString().c_str());
}


