﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QMap>
#include <QString>
#include "ui_form.h"

namespace Ui {
    class Form;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = 0);
    ~Widget();
private slots:
    void newListen();
    void newConnetion();
    void getData();
    void sendData();

private:
    Ui::Form *ui;

    QString ip;
    QString port;

    QTcpServer *server;
    QTcpSocket *socket;
    QMap<QString,QTcpSocket*> s_map;
};
#endif // WIDGET_H
